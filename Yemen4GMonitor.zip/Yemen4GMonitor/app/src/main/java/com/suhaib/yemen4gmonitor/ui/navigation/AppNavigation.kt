package com.suhaib.yemen4gmonitor.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import com.suhaib.yemen4gmonitor.R
import com.suhaib.yemen4gmonitor.data.model.QueryResult
import com.suhaib.yemen4gmonitor.data.repository.Yemen4GRepository
import com.suhaib.yemen4gmonitor.ui.captcha.CaptchaWebViewScreen
import com.suhaib.yemen4gmonitor.ui.dashboard.DashboardScreen
import com.suhaib.yemen4gmonitor.ui.onboarding.OnboardingScreen
import com.suhaib.yemen4gmonitor.ui.settings.SettingsScreen
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * A deliberately simple, explicit screen state machine -- mirrors the states
 * called out in the spec (NO_SAVED_NUMBER, READY, LOADING, CAPTCHA_REQUIRED,
 * SUCCESS, ERROR, ...). A full navigation graph would add indirection with
 * no real benefit for an app this size.
 */
private sealed class Screen {
    data object Onboarding : Screen()
    data class Captcha(val persistAsSaved: Boolean, val queriedPhone: String) : Screen()
    data class Dashboard(val result: QueryResult, val isStale: Boolean) : Screen()
    data object Settings : Screen()
    data object Loading : Screen()
}

@Composable
fun AppRoot(startWithNumberEntry: Boolean = false) {
    val context = LocalContext.current
    val repository = remember { Yemen4GRepository.getInstance(context) }
    val scope = rememberCoroutineScope()

    var screen by remember { mutableStateOf<Screen>(Screen.Loading) }
    var savedNumber by remember { mutableStateOf<String?>(null) }
    var themeMode by remember { mutableStateOf("system") }
    var lastError by remember { mutableStateOf<String?>(null) }

    // Initial load: decide NO_SAVED_NUMBER vs READY(with cached result) vs onboarding.
    LaunchedEffect(Unit) {
        savedNumber = repository.getSavedNumber()
        themeMode = repository.themeModeFlow.first()
        val cached = repository.getLastResult()
        screen = when {
            startWithNumberEntry -> Screen.Onboarding
            savedNumber == null -> Screen.Onboarding
            cached != null -> Screen.Dashboard(cached, isStale = true)
            else -> Screen.Onboarding
        }
    }

    when (val s = screen) {
        is Screen.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }

        is Screen.Onboarding -> {
            OnboardingScreen(
                initialPhone = savedNumber ?: "",
                subtitle = stringResource(R.string.onboarding_subtitle)
            ) { phone, save ->
                screen = Screen.Captcha(persistAsSaved = save, queriedPhone = phone)
            }
        }

        is Screen.Captcha -> {
            Box(modifier = Modifier.fillMaxSize()) {
                CaptchaWebViewScreen(
                    onResultText = { text ->
                        scope.launch {
                            val result = repository.onWebResultPageLoaded(text, s.queriedPhone, s.persistAsSaved)
                            if (result != null) {
                                if (s.persistAsSaved) savedNumber = s.queriedPhone
                                screen = Screen.Dashboard(result, isStale = false)
                            }
                            // If null: the page shown is not yet the result page (e.g. still on the
                            // CAPTCHA form) -- we simply keep waiting for the next page load, so we
                            // deliberately do NOT change screens here.
                        }
                    }
                )
            }
        }

        is Screen.Dashboard -> {
            DashboardScreen(
                result = s.result,
                isStale = s.isStale,
                onRefresh = { screen = Screen.Captcha(persistAsSaved = savedNumber != null, queriedPhone = s.result.phoneNumber) },
                onQueryAnother = { screen = Screen.Onboarding },
                onOpenSettings = { screen = Screen.Settings }
            )
        }

        is Screen.Settings -> {
            SettingsScreen(
                savedNumber = savedNumber,
                themeMode = themeMode,
                onChangeNumberClick = { screen = Screen.Onboarding },
                onForgetNumber = {
                    scope.launch {
                        repository.clearSavedNumber()
                        savedNumber = null
                    }
                },
                onThemeModeChange = {
                    themeMode = it
                    scope.launch { repository.setThemeMode(it) }
                },
                onBack = {
                    scope.launch {
                        val cached = repository.getLastResult()
                        screen = if (cached != null) Screen.Dashboard(cached, isStale = true) else Screen.Onboarding
                    }
                }
            )
        }
    }
}
