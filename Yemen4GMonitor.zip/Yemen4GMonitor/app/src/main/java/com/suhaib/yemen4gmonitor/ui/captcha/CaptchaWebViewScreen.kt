package com.suhaib.yemen4gmonitor.ui.captcha

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.suhaib.yemen4gmonitor.data.network.PtcResultParser
import com.suhaib.yemen4gmonitor.utils.Constants

/**
 * Loads the OFFICIAL svc.ptc.gov.ye/4g page in a plain WebView so the user
 * can enter the number and complete any CAPTCHA themselves, exactly like a
 * browser would. This app never reads, solves, or scripts around the
 * CAPTCHA field -- it only reads the *already visible* result page text
 * after the user has finished, the same way a person reading the screen
 * would.
 *
 * @param onResultText called with the plain text of every page the WebView
 *        finishes loading, so the caller can decide (via [PtcResultParser])
 *        whether a real result is now on screen.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun CaptchaWebViewScreen(
    onResultText: (String) -> Unit,
    onLoadingChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    var progress by remember { mutableStateOf(0) }

    Column(modifier = Modifier.fillMaxSize()) {
        if (progress in 1..99) {
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.fillMaxWidth()
            )
        }
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = {
                WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                            onLoadingChanged(true)
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            onLoadingChanged(false)
                            // Read the text that is already rendered on screen for the
                            // user -- this is not a CAPTCHA bypass, it runs only after
                            // the page (result or otherwise) has fully loaded.
                            view?.evaluateJavascript(PtcResultParser.EXTRACTION_JS) { value ->
                                val unescaped = value
                                    ?.removeSurrounding("\"")
                                    ?.replace("\\n", "\n")
                                    ?.replace("\\\"", "\"")
                                    ?: ""
                                onResultText(unescaped)
                            }
                        }
                    }
                    webChromeClient = object : android.webkit.WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            progress = newProgress
                        }
                    }
                    loadUrl(Constants.PTC_QUERY_URL)
                }
            }
        )
    }
}
