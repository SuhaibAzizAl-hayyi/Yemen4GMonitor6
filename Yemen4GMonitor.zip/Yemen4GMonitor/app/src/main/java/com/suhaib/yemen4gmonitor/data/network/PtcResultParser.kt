package com.suhaib.yemen4gmonitor.data.network

import com.suhaib.yemen4gmonitor.data.model.QueryResult

/**
 * IMPORTANT / HONEST LIMITATION:
 * ------------------------------------------------------------------
 * svc.ptc.gov.ye/4g has no published public API. This app never bypasses,
 * solves, or automates the CAPTCHA -- the user completes it themselves
 * inside the embedded WebView (see ui/captcha/CaptchaWebViewScreen.kt).
 *
 * Once the *user* has submitted the form and the result page has loaded,
 * this class makes a best-effort attempt to read the *already-rendered,
 * already-visible* text of that page (via WebView.evaluateJavascript
 * reading document.body.innerText, which is not a bypass of anything --
 * it is the same content already shown to the user) and extract the
 * fields the user asked for.
 *
 * Because the exact HTML/CSS structure of svc.ptc.gov.ye was not
 * available to verify against at build time, the extraction below is
 * intentionally conservative: it looks for the Arabic labels most PTC
 * self-service pages use, and it leaves a field null (never guessed)
 * whenever it cannot find a confident match. If PTC changes their page
 * markup or labels, update the regexes in [extract] -- they are kept in
 * one place on purpose.
 */
object PtcResultParser {

    /** Injected into the WebView after the result page finishes loading. */
    const val EXTRACTION_JS = """
        (function() {
            try {
                return document.body ? document.body.innerText : '';
            } catch (e) {
                return '';
            }
        })();
    """

    private val phoneRegex = Regex("""(10\d{7})""")
    private val packageRegex = Regex("""(?:الباقة|الرصيد|Package)\s*[:\-]?\s*(.+)""")
    private val financialRegex = Regex("""(?:الرصيد المالي|رصيد نقدي)\s*[:\-]?\s*([\d.,]+\s*ريال)""")
    private val inNetworkRegex = Regex("""(?:داخل الشبكة|دقائق داخل)\s*[:\-]?\s*(.+)""")
    private val outNetworkRegex = Regex("""(?:خارج الشبكة|دقائق خارج)\s*[:\-]?\s*(.+)""")
    private val dataRegex = Regex("""(?:رصيد البيانات|الإنترنت|Data)\s*[:\-]?\s*([\d.,]+\s*(?:GB|MB|جيجا|ميجا))""", RegexOption.IGNORE_CASE)
    private val expiryRegex = Regex("""(?:تاريخ الانتهاء|ينتهي في|Expiry)\s*[:\-]?\s*(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})""")
    private val numberOnlyRegex = Regex("""([\d.]+)""")

    /**
     * @param rawPageText the plain text extracted from the result page's DOM
     * @param queriedPhone the phone number the user actually queried, used as a fallback
     * @return a QueryResult with every field that could be confidently found; null fields
     *         are left null on purpose rather than guessed.
     */
    fun extract(rawPageText: String, queriedPhone: String): QueryResult? {
        if (rawPageText.isBlank()) return null

        val phone = phoneRegex.find(rawPageText)?.value ?: queriedPhone

        val packageName = packageRegex.find(rawPageText)?.groupValues?.get(1)?.trim()?.take(40)
        val financial = financialRegex.find(rawPageText)?.groupValues?.get(1)?.trim()
        val inNet = inNetworkRegex.find(rawPageText)?.groupValues?.get(1)?.trim()?.take(40)
        val outNet = outNetworkRegex.find(rawPageText)?.groupValues?.get(1)?.trim()?.take(40)
        val expiry = expiryRegex.find(rawPageText)?.groupValues?.get(1)?.trim()

        val dataMatch = dataRegex.find(rawPageText)?.groupValues?.get(1)?.trim()
        val dataGb = dataMatch?.let { raw ->
            val num = numberOnlyRegex.find(raw)?.value?.toDoubleOrNull()
            when {
                num == null -> null
                raw.contains("MB", ignoreCase = true) || raw.contains("ميجا") -> num / 1024.0
                else -> num
            }
        }

        // If we found nothing at all, treat this as "could not parse" rather than a fake success.
        if (packageName == null && financial == null && inNet == null && outNet == null && dataMatch == null) {
            return null
        }

        return QueryResult(
            phoneNumber = phone,
            packageName = packageName,
            financialBalance = financial,
            inNetworkMinutes = inNet,
            outNetworkMinutes = outNet,
            dataBalanceRaw = dataMatch,
            dataBalanceGb = dataGb,
            packageTotalGb = null, // Never inferred from the package *name* -- see rule #10 in the spec.
            expiryDate = expiry
        )
    }
}
