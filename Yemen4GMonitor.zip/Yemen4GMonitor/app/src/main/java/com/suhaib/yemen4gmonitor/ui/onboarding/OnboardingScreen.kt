package com.suhaib.yemen4gmonitor.ui.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.suhaib.yemen4gmonitor.R
import com.suhaib.yemen4gmonitor.utils.Constants

/**
 * First-run screen, and also reused for "query another number".
 *
 * @param title customizable so the same composable serves both the first-run
 *              flow (section 4) and the "query another number" flow (section 7)
 */
@Composable
fun OnboardingScreen(
    title: String = stringResource_appName(),
    subtitle: String? = null,
    initialPhone: String = "",
    onSubmit: (phone: String, save: Boolean) -> Unit
) {
    var phone by remember { mutableStateOf(initialPhone) }
    var save by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Filled.Wifi,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(text = title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        if (subtitle != null) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(modifier = Modifier.height(32.dp))

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it.filter(Char::isDigit).take(9); error = null },
            label = { Text(stringResource_phoneLabel()) },
            placeholder = { Text("10XXXXXXX") },
            singleLine = true,
            isError = error != null,
            supportingText = { if (error != null) Text(error!!) },
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = save, onCheckedChange = { save = it })
            Text(stringResource_saveNumber())
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (!Regex(Constants.PHONE_REGEX).matches(phone)) {
                    error = "أدخل رقماً صحيحاً مكوناً من 9 أرقام يبدأ بـ 10"
                } else {
                    onSubmit(phone, save)
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = MaterialTheme.shapes.large
        ) {
            Icon(Icons.Filled.Search, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(stringResource_queryButton())
        }
    }
}

// Small local helpers so this file can be previewed without a full resources
// pipeline; in the real app these simply forward to strings.xml via
// androidx.compose.ui.res.stringResource(R.string.xxx).
@Composable private fun stringResource_appName() = androidx.compose.ui.res.stringResource(R.string.app_name)
@Composable private fun stringResource_phoneLabel() = androidx.compose.ui.res.stringResource(R.string.phone_number_label)
@Composable private fun stringResource_saveNumber() = androidx.compose.ui.res.stringResource(R.string.save_number_checkbox)
@Composable private fun stringResource_queryButton() = androidx.compose.ui.res.stringResource(R.string.query_button)
