package com.suhaib.yemen4gmonitor.data.repository

import android.content.Context
import com.suhaib.yemen4gmonitor.data.local.PreferencesRepository
import com.suhaib.yemen4gmonitor.data.model.QueryResult
import com.suhaib.yemen4gmonitor.data.network.PtcResultParser
import kotlinx.coroutines.flow.Flow

/**
 * Coordinates local storage with results produced by the CAPTCHA-safe
 * WebView flow. There is no remote backend and no automated CAPTCHA
 * handling anywhere in this class.
 */
class Yemen4GRepository(context: Context) {

    private val prefs = PreferencesRepository.getInstance(context)

    val savedNumberFlow: Flow<String?> = prefs.savedNumberFlow
    val themeModeFlow: Flow<String> = prefs.themeModeFlow

    suspend fun getSavedNumber(): String? = prefs.getSavedNumber()
    suspend fun setSavedNumber(phone: String) = prefs.saveNumber(phone)
    suspend fun clearSavedNumber() = prefs.clearSavedNumber()
    suspend fun setThemeMode(mode: String) = prefs.setThemeMode(mode)
    suspend fun getLastResult(): QueryResult? = prefs.getLastResult()

    /**
     * Called after the embedded WebView finishes loading the result page
     * that the *user* reached by completing the CAPTCHA themselves.
     * [rawPageText] is document.body.innerText from that already-visible page.
     */
    suspend fun onWebResultPageLoaded(rawPageText: String, queriedPhone: String, persistAsSaved: Boolean): QueryResult? {
        val result = PtcResultParser.extract(rawPageText, queriedPhone) ?: return null
        prefs.saveLastResult(result)
        if (persistAsSaved) {
            prefs.saveNumber(queriedPhone)
        }
        return result
    }

    companion object {
        @Volatile private var INSTANCE: Yemen4GRepository? = null
        fun getInstance(context: Context): Yemen4GRepository =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Yemen4GRepository(context.applicationContext).also { INSTANCE = it }
            }
    }
}
