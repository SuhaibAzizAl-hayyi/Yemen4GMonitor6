package com.suhaib.yemen4gmonitor.utils

object Constants {
    /** Official PTC Yemen 4G self-service query page. The user completes any CAPTCHA themselves. */
    const val PTC_QUERY_URL = "https://svc.ptc.gov.ye/4g/"

    const val PREFS_DATASTORE_NAME = "yemen4g_monitor_prefs"

    const val PHONE_REGEX = "^10[0-9]{7}$"

    const val WIDGET_UPDATE_ACTION = "com.suhaib.yemen4gmonitor.widget.ACTION_REFRESH"
    const val WIDGET_EXTRA_PHONE = "extra_phone_number"
}
