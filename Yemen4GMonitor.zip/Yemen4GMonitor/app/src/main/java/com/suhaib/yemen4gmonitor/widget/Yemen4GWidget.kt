package com.suhaib.yemen4gmonitor.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.LocalSize
import androidx.glance.action.clickable
import androidx.glance.appwidget.DpSize
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.suhaib.yemen4gmonitor.MainActivity
import com.suhaib.yemen4gmonitor.data.model.QueryResult
import com.suhaib.yemen4gmonitor.data.repository.Yemen4GRepository

/**
 * Home screen widget. Three responsive layouts (small / medium / large) as
 * required by the spec. The widget only ever displays the same QueryResult
 * that is cached from the last *user-completed* query -- it never invents
 * data and it never attempts to solve or bypass a CAPTCHA in the background.
 * Tapping refresh opens the app so the user can complete the CAPTCHA-safe
 * WebView flow themselves; see ui/captcha/CaptchaWebViewScreen.kt.
 */
class Yemen4GWidget : GlanceAppWidget() {

    companion object {
        val SMALL = DpSize(110.dp, 60.dp)
        val MEDIUM = DpSize(220.dp, 110.dp)
        val LARGE = DpSize(280.dp, 180.dp)
    }

    override val sizeMode = SizeMode.Responsive(setOf(SMALL, MEDIUM, LARGE))

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val repository = Yemen4GRepository.getInstance(context)
        val savedNumber = repository.getSavedNumber()
        val result = repository.getLastResult()

        provideContent {
            val size = LocalSize.current
            WidgetContent(
                hasSavedNumber = savedNumber != null,
                result = result,
                compact = size.width < MEDIUM.width
            )
        }
    }
}

@Composable
private fun WidgetContent(hasSavedNumber: Boolean, result: QueryResult?, compact: Boolean) {
    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ColorProvider(day = Color(0xFFFFFFFF), night = Color(0xFF1B2330)))
            .cornerRadius(20.dp)
            .padding(12.dp)
    ) {
        Row(
            modifier = GlanceModifier.fillMaxWidth(),
            verticalAlignment = Alignment.Vertical.CenterVertically
        ) {
            Text(
                text = "📶 يمن 4G",
                style = TextStyle(fontWeight = FontWeight.Bold, fontSize = 14.sp)
            )
            Spacer(modifier = GlanceModifier.width(6.dp))
            Text(
                text = "🔄",
                modifier = GlanceModifier.clickable(actionStartActivity<MainActivity>())
            )
        }

        Spacer(modifier = GlanceModifier.height(8.dp))

        if (!hasSavedNumber || result == null) {
            Text(text = "لم يتم إعداد الرقم", style = TextStyle(fontSize = 12.sp))
            Text(
                text = "فتح التطبيق",
                modifier = GlanceModifier.clickable(actionStartActivity<MainActivity>())
            )
        } else {
            Text(
                text = result.dataBalanceRaw ?: "—",
                style = TextStyle(fontWeight = FontWeight.Bold, fontSize = if (compact) 18.sp else 26.sp)
            )
            Text(text = "متبقي", style = TextStyle(fontSize = 11.sp))

            if (!compact) {
                Spacer(modifier = GlanceModifier.height(8.dp))
                Text(text = "الباقة: ${result.packageName ?: "—"}", style = TextStyle(fontSize = 11.sp))
                Text(text = "الانتهاء: ${result.expiryDate ?: "—"}", style = TextStyle(fontSize = 11.sp))
            }
        }
    }
}
